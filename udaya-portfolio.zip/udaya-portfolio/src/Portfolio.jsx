import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Github, Linkedin } from "lucide-react";
import { motion } from "framer-motion";

export default function Portfolio() {
  return (
    <main className="max-w-4xl mx-auto p-6 space-y-10 bg-gradient-to-b from-purple-50 via-white to-blue-100 min-h-screen">
      {/* Header */}
      <motion.section
        className="text-center"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold mb-2 text-purple-700">Udaya Geetha</h1>
        <p className="text-lg text-gray-600">Junior Full Stack Developer | TCS NQT Certified</p>
        <div className="flex justify-center gap-4 mt-4">
          <a href="https://github.com/Udayageetha" target="_blank" rel="noopener noreferrer">
            <Button variant="outline"><Github className="mr-2" /> GitHub</Button>
          </a>
          <a href="https://www.linkedin.com/in/udayageetha/" target="_blank" rel="noopener noreferrer">
            <Button variant="outline"><Linkedin className="mr-2" /> LinkedIn</Button>
          </a>
        </div>
      </motion.section>

      {/* About */}
      <motion.section
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-2xl font-semibold mb-2 text-blue-800">About Me</h2>
        <p className="text-gray-700">
          Hello! I'm Udaya Geetha, a passionate software developer focused on building responsive and dynamic web applications. I am currently working as a Junior Full Stack Developer at GoWebEz and have completed professional training with TCS in Python and cloud computing.
        </p>
      </motion.section>

      {/* Skills */}
      <motion.section
        initial={{ opacity: 0, x: 30 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-2xl font-semibold mb-2 text-blue-800">Skills</h2>
        <ul className="list-disc list-inside text-gray-700">
          <li>Java, Python, SQL</li>
          <li>HTML, CSS, JavaScript</li>
          <li>React, Git, GitHub</li>
          <li>Cloud Fundamentals (IBM Cloud)</li>
        </ul>
      </motion.section>

      {/* Projects */}
      <motion.section
        initial={{ opacity: 0 }}
        whileInView={{ opacity:1 }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="text-2xl font-semibold mb-4 text-blue-800">Projects</h2>

        <Card className="mb-4 bg-white shadow-lg hover:shadow-purple-300 transition">
          <CardContent className="p-4">
            <h3 className="text-xl font-bold text-purple-700">Estimate the Crop Yield using Data Analytics</h3>
            <p className="text-gray-700">A project focused on predicting crop yield using analytical models and IBM tools.</p>
            <a href="https://github.com/Udayageetha/IBM-Project-44807-1660726896" className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">View Project</a>
          </CardContent>
        </Card>

        <Card className="mb-4 bg-white shadow-lg hover:shadow-purple-300 transition">
          <CardContent className="p-4">
            <h3 className="text-xl font-bold text-purple-700">WebTech Project</h3>
            <p className="text-gray-700">A hands-on academic project exploring modern web technologies and practices.</p>
            <a href="https://github.com/Udayageetha/WEBTECH-PROJECT" className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">View Project</a>
          </CardContent>
        </Card>

        <Card className="mb-4 bg-white shadow-lg hover:shadow-purple-300 transition">
          <CardContent className="p-4">
            <h3 className="text-xl font-bold text-purple-700">ToDoList App</h3>
            <p className="text-gray-700">A simple Java-based ToDo list application to manage tasks efficiently.</p>
            <a href="https://github.com/Udayageetha/ToDoList" className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">View Project</a>
          </CardContent>
        </Card>
      </motion.section>

      {/* Contact */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-2xl font-semibold mb-2 text-blue-800">Get in Touch</h2>
        <p>Email: <span className="text-gray-700">udayageetha2002@gmail.com</span></p>
      </motion.section>
    </main>
  );
}